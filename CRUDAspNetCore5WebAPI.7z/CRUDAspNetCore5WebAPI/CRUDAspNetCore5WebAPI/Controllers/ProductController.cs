﻿using CRUD_BAL.Service;
using CRUD_DAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CRUDAspNetCore5WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly ProductService _productService;
        public ProductController(ProductService ProductService)
        {
            _productService = ProductService;
        }

        [HttpGet]
        public async Task<IEnumerable<Product>> GetProducts()
        {
            return await _productService.GetProducts();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProducts(int id)
        {
            var product = await _productService.GetProducts(id);
            return product == null ? NotFound() : Ok(product);
        }
        [HttpPost]
        public async Task<ActionResult<Product>> PostProducts([FromBody] Product product)
        {
            var newProduct = await _productService.AddProduct(product);

            return CreatedAtAction(nameof(GetProducts), new { id = newProduct.ProductId }, newProduct);
        }

        [HttpPut("{id}")]
        public Boolean PutProducts([FromBody] Product product)
        {
            try
            {
                _productService.UpdateProduct(product);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        [HttpDelete("{id}")]
        public Boolean DeleteProducts(int id)
        {
            try
            {
                _productService.DeleteProduct(id);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}
